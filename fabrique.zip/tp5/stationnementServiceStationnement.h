#pragma once
#include <iostream>
#include "Stationnement.h"
class StationnementServiceStationnement : public Stationnement {
public:
    void printVehicle();
};

