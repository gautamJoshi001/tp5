#pragma once
#include <iostream>
#include "Stationnement.h"
class StationnementResident : public Stationnement {
public:
    void printVehicle();
};

