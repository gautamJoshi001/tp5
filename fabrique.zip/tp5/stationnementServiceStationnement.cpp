#include "stationnementServiceStationnement.h"
#include <iostream>

void StationnementServiceStationnement::printVehicle()
{
	std::cout << "stationnement dans la ville disponible " << std::endl;
}
