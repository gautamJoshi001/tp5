#pragma once
#include "Stationnement.h"
class StationnementPrive : public Stationnement {
public:
    ///surcharge la methode virtuelle dans la classe Stationnment
    void printVehicle();
};
