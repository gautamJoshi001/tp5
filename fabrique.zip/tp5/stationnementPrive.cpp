#include "stationnementPrive.h"
#include <iostream>

void StationnementPrive::printVehicle()
{
	std::cout << "Stationnement Prive disponible" << std::endl;
}
