#include "stationnnementResident.h"

void StationnementResident::printVehicle()
{
	std::cout << "Stationnement Residentiel disponible " << std::endl;
}
