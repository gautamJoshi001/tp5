#pragma once
#pragma once

#include "Mediateur.h"
#include "Collegue.h"
#include "CollegueConcret.h"

/**
 * Les m�diateurs concrets mettent en �uvre un comportement coop�ratif en coordonnant plusieurs
 * Composants.
 */
class MediateurConcret : public Mediateur {
private:
    Vignette* vignette;
    Conducteur* conducteur;
    ServeurCentral* serveurCentral;

public:
    MediateurConcret(Vignette* c1, Conducteur* c2, ServeurCentral* c3) : vignette(c1), conducteur(c2), serveurCentral(c3) {
        vignette->setMediateur(this);
        conducteur->setMediateur(this);
        serveurCentral->setMediateur(this);
    }
    //Methode qui s'occupe de communiquer avec les autres classes selon les messages recus.

    void Informer(Collegue* expediteur, std::string message) const override {
        if (message == "A") {
            // std::cout << "Le serveur central a recu la destination et la location du conducteur:\n";
            serveurCentral->CalculerItinaire();
        }
        if (message == "C") {
            // std::cout << "    Le mediateur met a jour les collegues 1 et 2:\n";
            serveurCentral->demanderLaPositionDuClient();
        }
        if (message == "E")
        {
            std::cout << "   le mediateur annonce l'itinaire au conducteur\n";

        }
        if (message == "F") {
            vignette->TrouverLaPostion();
            vignette->EnvoyerPostionDuClient();
        }
    }
};