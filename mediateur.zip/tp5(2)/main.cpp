///source: le fichier d'exercice sur les mediateur(cours 8) du cours de Eric Demers
//https://refactoring.guru/fr/design-patterns/mediator/cpp/example

#include <iostream>
#include <string>
#include <memory>
#include "Mediateur.h"
#include "MediateurConcret.h"
#include "Collegue.h"
#include "CollegueConcret.h"


/**
 * Le code client.
 */

void CodeClient() {
    Vignette collegue1;
    Conducteur conducteur;
    ServeurCentral collegue3;
    MediateurConcret mediator(&collegue1, &conducteur, &collegue3);
    std::cout << "Debut de la simulation pour le patron mediateur.\n";
    conducteur.ChoisirStationnement();
}

int main() {
    CodeClient();
    return 0;
}