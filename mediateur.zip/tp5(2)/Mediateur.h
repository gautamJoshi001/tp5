#pragma once
#pragma once
#include <string>


/**
 *
 * L'interface Mediator d�clare une m�thode utilis�e par les coll�gues pour notifier le
 * m�diateur sur divers �v�nements. Le M�diateur peut r�agir � ces �v�nements et
 * transmettre l'ex�cution � d'autres coll�gues.
 */


class Mediateur {
public:
    virtual void Informer(class Collegue* expediteur, std::string message) const = 0;
};

