#pragma once
#pragma once

#include "Mediateur.h"
#include <iostream>

/**
 * Le classe de base Collegue fournit la fonctionnalit� de stockage d'un m�diateur
 * � l'int�rieur ses classes d�riv�es.
 */
class Collegue {
protected:
    Mediateur* m_mediateur;

public:
    Collegue(Mediateur* mediateur = nullptr) : m_mediateur(mediateur) {
    }
    void setMediateur(Mediateur* mediateur) {
        m_mediateur = mediateur;
    }

    virtual ~Collegue() = default;

};


