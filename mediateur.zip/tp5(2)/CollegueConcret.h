#pragma once

#include "Collegue.h"
#include <iostream>


/**
 * Les CollegueConcrets impl�mentent diverses fonctionnalit�s. Ils ne d�pendent pas des
 * autres collegue. Ils ne d�pendent pas non plus des classes M�diateurConcrets.
 */
class Vignette : public Collegue {
public:
    void EnvoyerPostionDuClient() {
        std::cout << " Le conducteur se trouve a 1234 av.jeSaisPas,Montreal.\n";
        m_mediateur->Informer(this, "A");
    }
    void TrouverLaPostion()
    {
        std::cout << "La vignette chercher la postion du client ..." << std::endl;
    }
};

class Conducteur : public Collegue {
public:
    void ChoisirStationnement() {
        std::cout << "  Le conducteur veut aller au Centre Bell.\n";
        m_mediateur->Informer(this, "C");
    }
    void messageD() {
        std::cout << " Le conducteur a recu l'itinaire.\n";
    }
};

class ServeurCentral : public Collegue
{
public:
    void CalculerItinaire()
    {
        m_mediateur->Informer(this, "E");
    }

    void demanderLaPositionDuClient()
    {
        std::cout << "  le seveur central demande les coorodonnes du conducteur a la vignette. " << std::endl;
        m_mediateur->Informer(this, "F");
    }
};

